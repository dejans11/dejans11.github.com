# Reference notes

## Primary visual references
The user supplied two DOS screenshots: [title](https://images.launchbox-app.com/ee7bbbd1-6195-4cde-abe2-4b707e641a56.png) and [team selection](https://images.launchbox-app.com/2190540a-9565-4b75-ab68-d937d64a1293.png). Both were downloaded to `docs/references/` and inspected. They are reference material only and are not embedded in the game. The title uses a green/red football scene; the tactics view combines green turf, cyan panels and magenta lettering, with paired opponents and player name/skill/fitness text.

## Gameplay evidence
The [Amiga manual](https://www.gamesdatabase.org/Media/SYSTEM/Commodore_Amiga/Manual/formated/Football_Manager_2_-_1988_-_Prism_Leisure_Corporation_Plc.htm) describes twelve zones, paired marking and randomized skill comparisons. Near-equal opponents can cancel each other; empty space is treated as skill 2. Out-of-position players also perform at skill 2. It specifies eleven starters, two substitutes, half-time formation changes, skill 3–9 and fitness 0–100; fitness below 50 means unavailable. Passing height and length change play. Each action ends with a save, goal or ball out. The home side begins attacking left to right.

It describes one league match against each opponent and three clubs promoted/relegated, along with two cups, sponsorship, wages, attendance income, transfers and dismissal for negative balance. The [Spectrum manual](https://www.gamesdatabase.org/Media/SYSTEM/Sinclair_ZX_Spectrum/Manual/formated/Football_Manager_2_-_1988_-_Addictive_Games.htm) corroborates these simple player attributes and the shortened season.

## Uncertainty and decisions
Neither platform manual proves exact DOS algorithms. No DOS-specific manual or direct DOS season playthrough establishing schedule length, points or promotion behavior was found. Phase 2 should use the documented once-per-opponent and three-up/three-down rules, label them as cross-platform approximations, and avoid substituting modern league rules silently.

Phase 2 now implements once-per-opponent schedules and three-up/three-down across each adjacent division. A selected higher-division club swaps membership with one Division 4 club so all 92 clubs and the 20/24/24/24 capacities remain intact. Three points for a win and one for a draw, goal-difference/goals-scored tie breaks, seeded cup draws, 92 entrants in each cup, preliminary byes and immediate penalties after a drawn 90 minutes are independent choices; exact DOS behavior for these details remains unverified. Seven rounds of each cup are interleaved through a 23-round league calendar.

The Amiga manual specifies season-start sponsor offers capped at £50,000 per division level, offers to sell up to player value, up to three market listings, wages for all squad members and dismissal for a negative bank balance. The implementation uses those features with independently chosen numerical economy formulas: £150,000 starting bank, squad wages × 1/1.25/1.5/1.75 from Division 4 to 1, £2,000–£5,000 overheads each calendar turn, base home receipts £18,000 plus £6,000 per higher division with seeded ±15%, quarter share away and ×1.3 in cups. Sale offers are 65–90% of value; affordable at-value bids are accepted and lower bids have a seeded chance proportional to bid/value. The 24-player squad cap, one attempted bid/sale offer per turn, fitness recovery rates and manager success-point formula are also approximations.

Sponsor rejection follows the manual's stated repeat-offer chances: none at rating 25 or below, 50% at rating 50 and 75% at rating 100, with interpolation between those values. Saves use validated versioned JSON, browser storage and exported files rather than the original machine media. Live matches resume from the pre-match boundary; league/cup results, fixtures, squads, economy and career records persist across seasons. Negative-bank dismissal occurs when each turn's accounts settle.

The exact DOS club list/order is unverified. The initial data uses the [1988–89 Football League cohort](https://en.wikipedia.org/wiki/1988%E2%80%9389_Football_League): 20, 24, 24, 24 clubs. These historical capacities are a data approximation, not a claim about the DOS edition. A selected club always starts in Division 4.

Independent match approximations: fitness scales natural-position skill; zone comparisons have seeded noise; passing success considers receiver and marker skill; high/long balls can bypass midfield; wing progression can create crosses; shots compare attacker skill with keeper and defensive pressure. The game derives its score directly from these actions. Pixel sprites, bitmap text and pitch graphics are newly authored code.

No supplementary ZIP was present in the attachment directory; the pasted brief was the only attachment.

## Phase 3 visual and control choices

The title is newly drawn Canvas art using the reference's red/cream/green stadium palette, terrace and kicking footballer. Paired Defence/Midfield/Attack screens use green turf, cyan borders and magenta player names. They show actual reversed-band, same-lane markers; Overview retains all thirteen zones and formation/bench controls. Similar kits receive a contrasting alternate, and shots, tackles, celebrations and goalkeeper dives have distinct sprite poses. Team names and multi-digit scores occupy separate bounded columns.

Q/S/I/P restore the original up/down/left/right key pattern alongside modern arrows. Spatial navigation, accessible HTML controls, Back/Help, keyboard pausing, visible feedback and portable ZIP packaging are convenience additions. Playback speeds are independent pacing choices, with an automatic half-time stop. The implementation aims for the DOS feel, rather than an exact ROM, screen or algorithm reproduction. The save format and Phase 2 gameplay/economy rules remain unchanged.
