# Retro Football Manager — Version 1 review build

An independently written tribute to the 1988 DOS Football Manager 2: animated matches, a continuing career and a red/green pixel stadium cover. The third and final phase adds paired marking screens, spatial keyboard navigation and gift packaging.

## Play offline on Windows

Open **`index.html` in this folder** by double-clicking it. Use a current Edge, Chrome or Firefox browser. The HTML includes the code, CSS, bitmap font and pixel artwork. No installation, Node.js, web server or internet connection is needed to play. You may copy that HTML file to another computer on its own.

1. Choose **New career**, select your club and choose **Take charge**. No club is selected initially; every club starts in Division 4. Use the search field to find any of the 92 clubs. **Continue** and **Import career** are separate title actions.
2. The **Career desk** shows your next league or cup fixture. Open **Finances** to accept or reject the annual sponsor offer. Review your generated squad: position G/D/M/A, skill, fitness and value. Eleven starters and two substitutes are initially picked for you.
3. Open **Tactics**. **Defence**, **Midfield** and **Attack** pair your players with their opposite markers; **Overview** shows all zones. Choose a player, then click a zone to place them. You can change area with a player selected. Clicking an occupied zone with a selected starter swaps positions. The goalkeeper has a separate slot. There are four slots each in defence, midfield and attack; leave two outfield slots empty.
4. Before kickoff, use the squad's **Reserve** and **Pick sub 1/2** controls to nominate your bench. Formation buttons in **Overview** select a fit team in 4-4-2, 4-3-3 or 3-4-3; these change actual player placement and the bench. The reserve box in paired tactics cycles through available reserves; the dropdown can select any player.
5. **Training** changes passing length and height. Short, low passes encourage close play; longer, higher passes can bypass midfield. Wide attackers can cross.
6. Choose **Kickoff**. Pause or cycle through 1×, 4× and 12× playback. The score follows goals in the actual simulated action.
7. At **half-time**, move starters between zones or select a named substitute and click the starter to replace. Up to two substitutions are allowed; a replaced player cannot return. Choose **Resume** when ready. Teams change ends.
8. Review the final score and statistics, then **Other results**, the league table and finances. Choose **Next turn** when ready. Players lose fitness after playing and recover between turns; below 50 fitness they cannot be selected.
9. Each divisional opponent is played once per season. Three clubs are promoted/relegated across each division boundary. Both cups have preliminary byes followed by knockout rounds; drawn cup matches go to penalties after the animated 90 minutes. If you have no fixture, choose **Rest / Other results**; wages and overheads still apply.
10. At season end, review your placing, movement, cup champions and managerial rating. **Continue to next season** retains your squad, bank balance and career record.

Playing a D in M/A or another incorrect group gives effective skill 2. Unmarked players have an advantage. Match outcomes use your actual lineup, skills, fitness and passing style, with seeded randomness.

Mouse and touch controls work on the screen. For keyboard controls, focus the screen: arrows move spatially; the original Q/S/I/P keys mean up/down/left/right. Enter selects. Space pauses/plays a live match and selects outside a match. Escape goes back or pauses a match; it keeps you at half-time until you choose Resume. Tab at the ends moves out of the Canvas. Expand **Controls & screen actions** for regular HTML buttons. **How to play** returns to the same screen with Back. Switching browser tabs pauses playback.

## Transfers and finances

Open **Transfers** from the career desk. Choose one of three listings: the bid field receives focus and identifies the player and value. Enter a whole-pound bid below the screen and press Enter or **Make bid**. A bid at the displayed value is accepted if affordable; lower bids may be refused. Each listing permits one attempted bid per turn. The squad limit is 24, with three squad pages when full. Feedback appears in full below the screen.

To sell, choose one of your players in the dropdown, request an offer, then accept or reject it. Selling removes them from the lineup/bench too. Selling down below thirteen players can lead to a 0–3 forfeit; buy replacements or pick a fit squad before kickoff. Formation buttons can rebuild a lineup after a sale or injury.

Sponsorship, gate receipts, wages, transfers and overheads affect the bank. A negative balance at settlement means dismissal. Reserve players still earn wages. Receipts are higher at home and in cup matches; rest turns earn no gate income.

## Saving and moving the game

The game auto-saves at management boundaries and after team changes. **Save / Load** also provides explicit browser save/load and portable **Export save file / Import save file**. Export downloads a JSON file: keep it alongside the game or move both to your friend's computer. Imported files are validated before replacing the current career.

On opening the game, no club is preselected. **Continue saved career** appears separately when a browser save exists. Browser storage belongs to that browser and file location; a different location or private browsing may not retain it. If saving is unavailable, the game reports that and export/import still works.

Save/export/load is available before kickoff and after full-time. Closing during a match resumes from the pre-match save. Keep an exported copy before choosing a new club: taking charge creates a new career and replaces the browser save.

## Website version

The website export is prepared for `https://dejans11.github.io/fun/lale-manager/`. A local export does not publish it; publication requires an approved website commit and a separately approved push.

The website repository's `npm run import:lale-manager -- --source <game-dist-folder>` copies the built HTML and unchanged offline ZIP, adds website navigation/pageview analytics only to the web HTML, and records release hashes. Rebuild the game before each export. The source repository and development files are not needed on GitHub Pages; shipped browser code is public.

With Node.js 22.12+ or a newer supported version, prepare and verify an update from this game folder in one command:

```powershell
npm run prepare:web -- --site "E:\dev\dejans11.github.com"
```

This runs game tests/build, exports the release, then runs website tests and release verification. Add `--screenshot <PNG>` to replace the gallery image. A failed step stops preparation. The command never initializes Git, commits or pushes. After the approved website push and successful GitHub Pages deployment, run `npm run verify:lale-manager -- --url https://dejans11.github.io/fun/lale-manager/` in the website folder to check the live files against the prepared release.

Update this workspace's and the website's publishing documentation together before preparing a release. The offline ZIP includes this README, so README updates also require a rebuild/export to refresh the downloadable documentation and release hashes.

Web careers stay in each visitor's browser. The offline file and website use different storage origins, so use Export/Import to move an existing career. There are no cloud accounts or automatic cross-device saves. The downloadable ZIP remains an offline build without website analytics. The public website calls the game Footsi, while keeping the existing URL and save key. See [website publishing instructions](https://github.com/dejans11/dejans11.github.com/blob/master/docs/LALE-MANAGER.md) and the source workspace's `docs/web-publishing.md` for the local handoff and development chat.

## Review boundary

Version 1 delivers four divisions, persistent generated squads, once-per-opponent schedules, standings, promotion/relegation, both cups, transfers, sponsorship and match accounts, injuries/rest, manager records, consecutive seasons and validated saves. Phase 3 completes the reference-inspired title, paired tactics, readable score columns, distinct player poses, keyboard/back/help navigation and portable gift ZIP.

The initial club data uses the real 1988–89 league cohort (20/24/24/24); the exact original DOS club ordering is unverified. The original-style match formulas are independent approximations. See [reference notes](reference-notes.md) for evidence and uncertainties.

## Development

With Node.js 20.19+ or 22.12+:

```text
npm install
npm run dev
npm test
npm run build
```

Build output is `dist/index.html` and `dist/retro-football-manager.zip`. Extract the ZIP before opening `index.html`; it includes this README and reference notes. Development dependencies do not accompany the game. The build checks TypeScript, generates a classic IIFE, embeds code/CSS, then makes a ZIP with fixed timestamps for reproducible packaging. The ZIP reader regression uses the system `tar` utility (included in current Windows).

Responsibilities: `clubs.ts` initial data; `random.ts` seeds; `squad.ts` players/selection; `match.ts` actions; `session.ts` playback; `competitions.ts` leagues/cups; `economy.ts` finances/transfers; `career.ts` progression; `persistence.ts` validated saves; `pixels.ts`/`graphics.ts` artwork; `screens.ts`/`career-screens.ts`/`tactics-screen.ts` views; `input.ts` input mapping; `app.ts` UI actions.

Browser QA uses Playwright CLI against the packaged `file://` HTML with networking disabled. `tests/browser-smoke.js` covers management, transfers, away half-time changes and save/export/import; `tests/browser-season.js` exercises up to ten calendar turns per call and checks season continuation. The CLI requires its supported `allowUnrestrictedFileAccess` configuration for local-file testing.

Local Git initialization and commits for the game and website were approved on 10 October 2026. No remote push or publication has been approved.
